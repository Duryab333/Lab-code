% Generate random bit vector
bitVectorLength = 1000;
bitVector = randi([0, 1], 1, bitVectorLength);

transmittedSymbols = bits2symbols(bitVector);

SNR = 15;
noisySymbols = addNoise(transmittedSymbols, SNR);

% Receiver: Demodulate symbols to bits
receivedBitVector = symbols2bits(noisySymbols);

% Plot the signal before and after the channel
figure;

% Transmitter (Plot QPSK symbols before modulation)
subplot(2, 1, 1);
plot(real(transmittedSymbols), imag(transmittedSymbols), 'bo');
title('QPSK Symbols Before Modulation');
xlabel('In-Phase');
ylabel('Quadrature');
grid on;

% Channel (Plot QPSK symbols after modulation and AWG noise)
subplot(2, 1, 2);
plot(real(noisySymbols), imag(noisySymbols), 'ro');
title('QPSK Symbols After Modulation and AWG Noise');
xlabel('In-Phase');
ylabel('Quadrature');
