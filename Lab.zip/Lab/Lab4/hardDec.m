function hardDecodedSymbols = hardDec(receivedSymbols)
   
    b = [-1-1i; -1+1i; 1-1i; 1+1i];
    hardDecodedSymbols = zeros(size(receivedSymbols));

   
    for i = 1:length(receivedSymbols)
       
        [~, index] = min(abs(b - receivedSymbols(i)));
  
        hardDecodedSymbols(i) = b(index);
    end
end