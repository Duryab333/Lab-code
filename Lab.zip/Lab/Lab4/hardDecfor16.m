function hardDecodedSymbols = hardDecfor16(receivedSymbols)
   
    b = [-1-1i; -1+1i; 1-1i; 1+1i ;-3-1i; -3+1i; 3-1i; 3+1i ;-1-3i; -1+3i; 1-3i; 1+3i ;-3-3i; -3+3i; 3-3i; 3+3i ];
    hardDecodedSymbols = zeros(size(receivedSymbols));

   
    for i = 1:length(receivedSymbols)
       
        [~, index] = min(abs(b - receivedSymbols(i)));
  
        hardDecodedSymbols(i) = b(index);
    end
end