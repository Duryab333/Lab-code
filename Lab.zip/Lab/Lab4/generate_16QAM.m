function modulated_signal = bits216QAMsymbols(bit_sequence)
    % Check if the input consists of only binary values (0 or 1)
    if any(bit_sequence ~= 0 & bit_sequence ~= 1)
        error('Input must contain only binary values (0 or 1).');
    end
    
       % Ensure the length of the input sequence is a multiple of 4 (as 4 bits form one 16-QAM symbol)
    if mod(length(bit_sequence), 4) ~= 0
        error('Input sequence length must be a multiple of 4 for 16-QAM modulation.');
    end
    
    I = zeros(1, length(bit_sequence) / 4);
    Q = zeros(1, length(bit_sequence) / 4);
    % Mapping bits to 16-QAM symbols
    for i = 1:4:length(bit_sequence)
        % Extract four bits to form one 16-QAM symbol
        bit_quad = bit_sequence(i:i+3);
     
        % Map the bit pairs to I and Q components
        if bit_quad(1) == 0
            if bit_quad(2) == 0
                Q((i + 3) / 4) = -3;
            else
                Q((i + 3) / 4) = -1;
            end   
        else   
        if bit_quad(2) == 1
               Q((i + 3) / 4) = 1;
        else
               Q((i + 3) / 4) = 3;
        end
        end    
        
        % Map the bit pairs to I and Q components
        if bit_quad(3) == 0
            if bit_quad(4) == 0
                I((i + 3) / 4) = 3;
            else
                I((i + 3) / 4) = 1;
            end   
        else   
        if bit_quad(3) == 1
               I((i + 3) / 4) = -1;
        else
               I((i + 3) / 4) = -3;
        end    
        end   
    end
        symbols = I + 1i * Q;
    
    % Scale the symbols to have an overall length of sqrt(2)
    symbols = symbols * 1;
    
    modulated_signal = symbols;
     





end