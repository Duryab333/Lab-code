function bit_sequence = symbols2bits_qam16(modulated_signal)
    bit_sequence = [];

    % Normalize the input symbols to have an overall length of sqrt(10)
    modulated_signal = modulated_signal / sqrt(10);
    bits = zeros(1, 4 * length(modulated_signal));

    for i = 1:length(modulated_signal)
        % Extract I and Q components of the 16-QAM symbol
        I_component = real(modulated_signal(i));
        Q_component = imag(modulated_signal(i));

        % Map I and Q components to binary bits using Gray coding
        if I_component < 0
            bits(4 * i - 3) = 0;
            bits(4 * i - 2) = 0;
        else
            bits(4 * i - 3) = 0;
            bits(4 * i - 2) = 1;
        end

        if Q_component < 0
            bits(4 * i - 1) = 0;
            bits(4 * i)     = 0;
        else
            bits(4 * i - 1) = 0;
            bits(4 * i)     = 1;
        end

        % Check the magnitude of I and Q components to determine the remaining bits
        if abs(I_component) > 1 / sqrt(10)
            bits(4 * i - 3) = bits(4 * i - 3) + 1;
        end

        if abs(Q_component) > 1 / sqrt(10)
            bits(4 * i - 1) = bits(4 * i - 1) + 1;
        end
    end

    bit_sequence = bits;
end
