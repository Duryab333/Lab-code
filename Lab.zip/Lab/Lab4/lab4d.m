SNR_values = 0:0.5:30;
BER_qpsk = zeros(size(SNR_values));
BER_16qam = zeros(size(SNR_values));

for i = 1:length(SNR_values)
    bitStream_qpsk = GenerateBitStream(10e3, 2);
    bitStream_16qam = GenerateBitStream(10e3, 4);

    qpskSymbols = bits2symbols(bitStream_qpsk);
    noisyQPSK = addNoise(qpskSymbols, SNR_values(i));
    hardDecodedQPSK = hardDec(noisyQPSK);
    receivedBitsQPSK = symbols2bits(hardDecodedQPSK);
   
    qamSymbols = bits216QAMsymbols(bitStream_16qam);
    noisy16QAM = addNoise(qamSymbols, SNR_values(i));
    hardDecoded16QAM = hardDecfor16(noisy16QAM);
    receivedBits16QAM = symbols2bits_qam16(hardDecoded16QAM);

    bitErrorsQPSK = sum(bitStream_qpsk ~= receivedBitsQPSK);
    BER_qpsk(i) = bitErrorsQPSK / length(bitStream_qpsk);

    bitErrors16QAM = sum(bitStream_16qam ~= receivedBits16QAM);
    BER_16qam(i) = bitErrors16QAM / length(bitStream_16qam);

end

% Plot the BER results
figure;
hold on;
plot(SNR_values, BER_qpsk, 'v--', 'LineWidth', 1.5);
plot(SNR_values, BER_16qam, 'd--', 'LineWidth', 1.5);
legend('QPSK', '16-QAM', 'Location', 'best');
xlabel('SNR (dB)');
ylabel('Bit Error Rate (BER)');
grid on;
box on;
set(gca, 'fontname', 'Times New Roman', 'FontWeight', 'bold');
set(gca, 'FontSize', 13.5);
set(gca, 'YScale', 'log');
