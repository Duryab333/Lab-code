%% Noise adding function
% IB 23.11.2022


function xout = addNoise(xin,SNR)


signalVec=xin;

nSamples = size(signalVec, 1);
[D, npc] = signalDims(signalVec);

% Average total power in signal matrix
results.Es = mean(sum(abs(signalVec).^2, 2), 1); % Es, signal energy in D dimensions

% Total noise power
results.N0 = results.Es*10^(-SNR/10); % N0 = Es/SNR, by definition

% Total noise variance
results.sigma2 = results.N0 .*(1 - 0.5*(D==1));
% Noise variance per dimension: results.sigma2(iBand)/D

% Generate noise
randStream = RandStream('mt19937ar', 'Seed', 1);
%
% Generate normal distributed random variable with total variance
% sigma2 and variance per dimension sigma2/D
noiseMatrix = randn(randStream, nSamples, D)*sqrt(results.sigma2/D);
% Now, we should have: results.sigma2(iBand) != mean(sum(abs(noiseMatrix).^2, 2), 1)

% Variance in each complex column should correspond to sigma2/D
noiseBand = setSamples(noiseMatrix, npc);

signalVec = signalVec + noiseBand;


xout=signalVec;


% Helper Functions
    function sampleMat = setSamples(samples, npc)
        sampleMat = zeros(size(samples, 1), length(npc));
        cntr = 1;
        for i = 1:length(npc)
            if npc(i) == 1
                sampleMat(:,i) = samples(:,cntr);
                cntr = cntr + 1;
            else
                sampleMat(:,i) = complex(samples(:,cntr), samples(:,cntr+1));
                cntr = cntr + 2;
            end
        end
    end

    function [N, Nv] = signalDims(X)
        validateattributes(X, {'numeric'}, {})
        Nv = any(imag(X),1) + 1;
        N = sum(Nv,2);
    end
end