%task 4(c)
% for QPSK

SNR_dB = 7;
bitStream=GenerateBitStream(10e3,2);
qpskSymbols = bits2symbols(bitStream); 
noisyQPSK = addNoise(qpskSymbols, SNR_dB);
hardDecodedQPSK = hardDec(noisyQPSK);
recivebits=symbols2bits(hardDecodedQPSK);

bitErrors = sum(bitStream ~= recivebits);
BER = bitErrors / length(bitStream);
disp(['Bit Error Rate (BER): ', num2str(BER)]);
figure;
subplot(2, 1, 1);
plot(real(noisyQPSK), imag(noisyQPSK), '.');
title(['QPSK Signal  Channel with SNR = ', num2str(SNR_dB), ' dB']);
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');

subplot(2, 1, 2);

plot(real(hardDecodedQPSK), imag(hardDecodedQPSK), 'o');
title('QPSK Signal after Channel');
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');

%%
%task 4(c) for 16QAM
SNR_dB = 10;
bitStream=GenerateBitStream(10e3,2);
S16qpskSymbols = bits216QAMsymbols(bitStream); 
noisy16QPSK = addNoise(S16qpskSymbols, SNR_dB);
hardDecoded16QPSK = hardDecfor16(noisy16QPSK);
recivebits= symbols2bits_qam16(hardDecoded16QPSK);

bitErrors = sum(bitStream ~= recivebits);
BER = bitErrors / length(bitStream);
disp(['Bit Error Rate (BER): ', num2str(BER)]);

figure;
subplot(2, 1, 1);
plot(real(noisy16QPSK), imag(noisy16QPSK), '.');
title(['QPSK Signal  Channel with SNR = ', num2str(SNR_dB), ' dB']);
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');

subplot(2, 1, 2);

plot(real(hardDecoded16QPSK), imag(hardDecoded16QPSK), 'o');
title('QPSK Signal after Channel');
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');
