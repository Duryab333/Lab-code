%task 4(b)
SNR_dB = 15;
bitStream=GenerateBitStream(10e3,2);
S16qpskSymbols = bits216QAMsymbols(bitStream); 
noisy16QPSK = addNoise(S16qpskSymbols, SNR_dB);
hardDecoded16QPSK = hardDecfor16(noisy16QPSK);
recivebits=symbols2bits_qam16(hardDecoded16QPSK);
figure;
subplot(2, 1, 1);
plot(real(noisy16QPSK), imag(noisy16QPSK), '.');
title(['16QAM Signal  Channel with SNR = ', num2str(SNR_dB), ' dB']);
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');

subplot(2, 1, 2);

plot(real(hardDecoded16QPSK), imag(hardDecoded16QPSK), 'o');
title('16QAM Signal after Channel');
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');



