%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sampling rate
f_a=44;

% Simulated duration
T=300; % seconds

% Signal mode
signal_mode=5;

% Frequency of the square wave, sine wave, and cosine wave
f0=0.5; % Hz

% Signal activation time
T_ein=0; % seconds

% Signal deactivation time
T_aus=300; % seconds

% Highest represented frequency
fg=22; % Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Generation of the sampled signal
signal=source(signal_mode,f_a,T,f0,T_ein,T_aus);

% Spectrum of the sampled signal
[f,freq]=spectrum(signal,f_a,fg,floor(f_a*T)+1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output of Simulation Results in the Frequency Domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure('Name','Frequency Domain');
plot(f{1},freq{1},'-b');
grid on;
xlabel('Frequency in Hz');
ylabel('Amplitude');
axis([-fg fg 0 Inf]);
