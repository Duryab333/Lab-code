%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Vector of sampling rates
f_a=[2, 1, 0.5,0.3]; % Hz - please complete this vector!

% Simulated duration
T=20; % seconds
% signal modes representing different signal functions(sinc, sine, cosine , unitstep, and a custom signal with subsampling.)
signal_mode=2; %mode2 means we are sellecting sin fuction

%: Frequency of the signal.
f0=1/3; % Hz

% Time intervals for signal generation.
T_ein=0; % seconds
T_aus=20; % seconds

%Number of samples.
N=1000;

%Frequency for plotting in the frequency domain.
fg=1.5; % Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%the source function generates the source signal based on the signal mode and specified parameters 
signal=source(signal_mode,f_a,T,f0,T_ein,T_aus);

%Performs time reconstruction of the signal.
recon=time_recon(signal,f_a,T,N);

%Computes the frequency spectrum of the signal.
[f,signal_frequency]=spectrum(signal,f_a,fg,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output of Simulation Results in the Time Domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure('Name','Time Domain');

colors=['r' 'b' 'g' 'k' 'c' 'm' 'y'];
markers=['+' 'o' '*' 'x' 's' 'd' '^'];

% Plotting the sampled values
%time domain plot with sampled values and reconstructed signals.

for l=1:length(f_a)
    t=0:1/f_a(l):T;
    stem(t,signal{l},[colors(mod(l,length(colors))) markers(mod(l,length(markers)))],'MarkerSize',10);
    hold on;
    
    % Legend entries
    if l==1
        l_str=['f_a=' num2str(f_a(1))];
    else
        l_str=str2mat(l_str, ['f_a=' num2str(f_a(l))]);
    end
end

% Plotting the reconstructed signals

for l=1:length(f_a)
    t=(0:N-1)/N*T;
    plot(t,recon{l},colors(mod(l,length(colors))));
    hold on;
end

%error= % Please complete!
%plot(t,error,'k','LineWidth',2);

grid on;
xlabel('Time in s');
ylabel('Amplitude');
% Displaying the legend
legend(l_str);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output of Simulation Results in the Frequency Domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% creates a frequency domain plot with reconstructed signals.

figure('Name','Frequency Domain');

% Plotting the reconstructed signals
for l=1:length(f_a)
    plot(f{l},signal_frequency{l},colors(mod(l,length(colors))));
    hold on;
end

grid on;
xlabel('Frequency in Hz');
ylabel('Amplitude');
axis([-fg fg -Inf Inf]);
% Displaying the legend
legend(l_str);
