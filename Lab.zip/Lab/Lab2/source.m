%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function signal=source(signal_mode,f_a,T,f0,T_ein,T_aus)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Shift for the Si-function
shift=10; % seconds

% Amplitude for a constant signal (signal_mode=4)
constant=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

signal=cell(length(f_a), 1); % Preallocate memory

% Simulate for all sampling rates f_a.
for l=1:length(f_a)
    t=0:1/f_a(l):T;

    switch signal_mode
        % 1. Function: sin(sx)/sx ;s = 2 pi (t-shift)
        case 1
            signal{l}=sinc(2*f0*(t-shift));

       
        case 2
            signal{l}=sin(2*pi*f0*t);

        
        case 3
            signal{l}=cos(2*pi*f0*t);

        
        case 4
            signal{l}=constant*ones(1,floor(T*f_a(l))+1);

        
        case 5
            % Factor for subsampling
            subsample=ceil(88/f_a);
            freq = zeros(1, floor(T*f_a/2*subsample)+1); % Preallocate memory
            for n=0:floor(T*f_a/2*subsample)
                f=n/T;
                if f>15.5
                    if f<=17
                        freq(n+1)=(f-15.5)/1.5;
                    elseif f<=19
                        freq(n+1)=1+(f-17)/30;
                    elseif f<=20.5
                        freq(n+1)=(20.5-f)/1.5*1.05;
                    else
                        freq(n+1)=0;
                    end
                else
                    freq(n+1)=0;
                end
            end
            
            % Add linear phase
            phase=2*pi*1i*(0:length(freq)-1)/length(freq)*1000;
            
            % Hermitian transfer function for real time signal
            freq=[freq.*exp(phase) freq(end:-1:2).*exp(-phase(end:-1:2))];
            
            % Generate time signal
            signal{l}=ifft(freq);
            
            % Subsample
            signal{l}=downsample(signal{l},subsample);
            
        otherwise
            error('Incorrect value for signal_mode in the source function');
    end
    
    % Signal is turned on at time T_ein
    if ceil(T_ein*f_a(l)) > 0
        signal{l}(1:ceil(T_ein*f_a(l))) = 0;
    end
    
    % Signal is turned off at time T_aus
    if floor(T_aus*f_a(l)) + 1 < length(signal{l})
        signal{l}(floor(T_aus*f_a(l))+1:end) = 0;
    end
end
