%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [f,signal_frequency]=spectrum(signal,f_a,fg,N)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Calculation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preallocate memory
f = cell(length(f_a), 1);
signal_frequency = cell(length(f_a), 1);

% Simulate for all sampling rates f_a
for l=1:length(f_a)
    
    % Zero-padding
    signal{l}=[signal{l} zeros(1,N-length(signal{l}))];
    
    % Magnitude of the Discrete Fourier Transformation
    signal_frequency{l}=abs(fft(signal{l}));

    % Number of periods of the signal in the frequency domain up to frequency f0
    periods=ceil(2*fg/f_a(l));
    signal_frequency{l}=repmat(signal_frequency{l},1,periods);

    % Shift low frequencies to the center
    signal_frequency{l}=circshift(signal_frequency{l},[0 round(length(signal_frequency{l})/2)]);
    
    f{l}=(-N/2*periods:N/2*periods-1)/N*f_a(l);
end
