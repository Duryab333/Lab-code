%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation Parameters
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sampling rate
f_a=5;

% Length of the Discrete Fourier Transform
N_0=16;

% Simulated duration
T=(N_0-1)/f_a; % seconds

% Signal mode
signal_mode=2;

% Frequency of the square wave, sine wave, and cosine wave
f0=0.5; % Hz

% Signal activation time
T_ein=0; % seconds

% Signal deactivation time
T_aus=1000; % seconds

% Number of values in the graphs
N=1000;

% Highest represented frequency
fg=f_a/2; % Hz

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulation
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Generation of the sampled signal
signal=source(signal_mode,f_a,T,f0,T_ein,T_aus);

% Generation of the "continuous" signal, for visualization purposes only
f_ueber=1000*2*f0;
signal_cont=source(signal_mode,f_ueber,T,f0,T_ein,T_aus);

% Discrete spectrum of the sampled signal
[f_disc,freq_disc]=spectrum(signal,f_a,fg,T*f_a+1);

% Continuous spectrum of the sampled signal
[f_cont,freq_cont]=spectrum(signal,f_a,fg,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output of Simulation Results in the Time Domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure('Name','Time Domain');

% Plotting the sampled values
t=0:1/f_a:T;
t_cont=0:1/f_ueber:T;
hold on;
stem(t,signal{1},'-or','MarkerSize',10);
plot(t_cont,signal_cont{1},'-b','MarkerSize',10);
hold off

grid on;
xlabel('Time in s');
ylabel('Amplitude');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Output of Simulation Results in the Frequency Domain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure('Name','Frequency Domain');

% Plotting the continuous spectrum and the sampled spectrum
hold on;
plot(f_cont{1},freq_cont{1},'-b', 'MarkerSize', 10)
stem(f_disc{1},freq_disc{1},'or','MarkerSize',10);
hold off

grid on;
xlabel('Frequency in Hz');
ylabel('Amplitude');
axis([-fg fg -Inf Inf]);

% Displaying the legend
legend('Spectrum','Sampled Spectrum');
