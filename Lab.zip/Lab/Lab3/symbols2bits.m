function bit_sequence = symbols2bits(modulated_signal)
     
    
    bitSequence = [];
  % Normalize the input symbols to have an overall length of sqrt(2)
    modulated_signal = modulated_signal / sqrt(2);
   bits = zeros(1, 2 * length(modulated_signal));
    
    for i = 1:length(modulated_signal)
        % Extract I and Q components of the QPSK symbol
        I_component = real(modulated_signal(i));
        Q_component = imag(modulated_signal(i));
        
        % Map I and Q components to binary bits
        if I_component < 0
            bits(2 * i - 1) = 0; % If I component is negative, set the first bit to 0
        else
            bits(2 * i - 1) = 1; % If I component is non-negative, set the first bit to 1
        end
          if Q_component < 0
            bits(2 * i) = 0;     % If Q component is negative, set the second bit to 0
        else
            bits(2 * i) = 1;     % If Q component is non-negative, set the second bit to 1
        end
    end
    
    bit_sequence = bits;
end