% $Id$

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Lab 3 - Filter
%
%
% 1.2: FIR Filter Design with Fourier Approximation - Introduction
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Clear all variables, close all figures, and clear command window
clear all;
close all;
clc;

%% Parameters

% Filter ------------------------------------
Wn = 0.4;       % Normalized cutoff frequency (1 corresponds to Nyquist frequency)
n = 21;         % Filter length
filt_amp = 1;   % Filter gain

%% Calculations

% Calculation of filter coefficients using Fourier approximation
b = Wn * sinc(Wn*(-(n-1)/2:(n-1)/2));

% Determine normalization factors in the frequency domain
[H W]  = freqz(b,1,4096);

% Scale filter coefficients to achieve the desired filter gain
b = filt_amp * b/H(1);

% Calculate the frequency response
[H W]  = freqz(b,1,4096);

% Calculate the phase response
phi = phasez(b,1,W);

%% Display frequency response (magnitude) and phase response
[AX,H1,H2] = plotyy(W/pi, abs(H),W/pi,phi);
grid on

% Labels
set(get(AX(1),'Ylabel'), ...
    'String','$|H(\exp(j \Omega))/H(1)|$', ...
    'Interpreter','Latex' ...
) 
set(get(AX(2),'Ylabel'), ...
    'String','Phase (radian)' ...
) 
xlabel('$\Omega / \pi$','Interpreter','Latex');

title('Assignment 1.2: Low-pass Phase and Magnitude Response');
