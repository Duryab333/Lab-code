a=GenerateBitStream(40e3,4);
Symbols16QPSK= generate_16QAM(a);
%plot
plot(real(Symbols16QPSK), imag(Symbols16QPSK), 'o');
title('QPSK Signal after Channel');
xlabel('In-Phase (I)');
ylabel('Quadrature (Q)');