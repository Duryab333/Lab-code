x=[1,2,3 : 4, 5 ,6];
%%
x=[1:0.02:2*pi];
y=sin(x);
%%plot(x,y)
%%
b=0;
for a=1:10
    b=b+a;
end
%%
x=0:0.1:2*pi;
%%figure; 
%%hold on;
%%plot(x,sin(x),'r.');
%%plot(x,cos(x),'b*');
%%title(' The graph of the sine and the cosine in [0,2/pi]');
%%xlabel('x');
%%ylabel('sin(x),cos(x)');
%%legend('sinus', 'Cosinus');
%%
r=rand(1,100);
% %%
a=GenerateBitStream(100e3,4)
