 

function modulated_signal = bits2symbols(bit_sequence)
    % Check if the input consists of only binary values (0 or 1)
    if any(bit_sequence ~= 0 & bit_sequence ~= 1)
        error('Input must contain only binary values (0 or 1).');
    end
    
    % Ensure the length of the input sequence is even (as 2 bits form one QPSK symbol)
    if mod(length(bit_sequence), 2) ~= 0
        error('Input sequence length must be a multiple of 2 for QPSK modulation.');
    end
    
    % Mapping bits to QPSK symbols
    bits_reshape = reshape(bit_sequence, 2, []).';  % Reshape bits into pairs
    symbols = exp(1i * pi/4 * (2 * bits_reshape(:,1) + bits_reshape(:,2))); % QPSK modulation
    
    % Scale the symbols to have an overall length of sqrt(2)
    symbols = symbols * sqrt(2);
    
    % Output the modulated signal
    modulated_signal = symbols;
end

