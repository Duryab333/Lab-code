a=GenerateBitStream(100e3,4);
b= bits2symbols(a)