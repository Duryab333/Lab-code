function bitstream=GenerateBitStream(bitrate,duration)
lengthBitStream=bitrate*duration;
bitstreamTemp=rand(1,lengthBitStream);
bitstream=round(bitstreamTemp);
end