function modulated_signal = bits2symbols(bit_sequence)
    % Check if the input consists of only binary values (0 or 1)
    if any(bit_sequence ~= 0 & bit_sequence ~= 1)
        error('Input must contain only binary values (0 or 1).');
    end
    
    % Ensure the length of the input sequence is even (as 2 bits form one QPSK symbol)
    if mod(length(bit_sequence), 2) ~= 0
        error('Input sequence length must be a multiple of 2 for QPSK modulation.');
    end
       
    % Initialize variables to store I and Q components of the QPSK symbols
    I = zeros(1, length(bit_sequence) / 2);
    Q = zeros(1, length(bit_sequence) / 2);
    
    for i = 1:2:length(bit_sequence)
        % Extract two bits to form one QPSK symbol
        bit_pair = bit_sequence(i:i+1);
        
        % Map the bit pairs to I and Q components
        if bit_pair(1) == 0
            I((i + 1) / 2) = -1; % If first bit is 0, set I component to -1
        else
            I((i + 1) / 2) = 1;  % If first bit is 1, set I component to 1
        end
        
        if bit_pair(2) == 0
            Q((i + 1) / 2) = -1; % If second bit is 0, set Q component to -1
        else
            Q((i + 1) / 2) = 1;  % If second bit is 1, set Q component to 1
        end
    end
    
    % Create complex QPSK symbols from I and Q components
    symbols = I + 1i * Q;
    
    % Scale the symbols to have an overall length of sqrt(2)
    symbols = symbols * 1;
    
    modulated_signal = symbols;
end
