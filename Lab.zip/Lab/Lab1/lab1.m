
r=rand(1,100);
a=GenerateBitStream(100e3,4)
