function modulated_signal = bits_to_symbols(bit_sequence, M)
      % Check if the input consists of only binary values (0 or 1)
    if any(bit_sequence ~= 0 & bit_sequence ~= 1)
        error('Input must contain only binary values (0 or 1).');
    end
    n=log2(M);
    % Ensure the length of the input sequence is a multiple of 4 (as 4 bits form one 16-QAM symbol)
    if mod(length(bit_sequence), n) ~= 0
        error('Input sequence length must be a multiple of 4 for 16-QAM modulation.');
    end
    
    I = zeros(1, length(bit_sequence) / n);
    Q = zeros(1, length(bit_sequence) / n);
    if (M==4)
     for i = 1:2:length(bit_sequence)
        % Extract two bits to form one QPSK symbol
        bit_pair = bit_sequence(i:i+1);
        
        % Map the bit pairs to I and Q components
        if bit_pair(1) == 0
            I((i + 1) / 2) = -1; % If first bit is 0, set I component to -1
        else
            I((i + 1) / 2) = 1;  % If first bit is 1, set I component to 1
        end
        
        if bit_pair(2) == 0
            Q((i + 1) / 2) = -1; % If second bit is 0, set Q component to -1
        else
            Q((i + 1) / 2) = 1;  % If second bit is 1, set Q component to 1
        end
    end
    
    
    end 
    if(M==16)
    % Mapping bits to 16-QAM symbols
    for i = 1:4:length(bit_sequence)
        % Extract four bits to form one 16-QAM symbol
            bit_quad = bit_sequence(i:i+3);
        
            % Map the bit pairs to I component
        if bit_quad(1) == 0
                if bit_quad(2) == 0
                    Q((i + 3) / 4) = -3;
                else
                    Q((i + 3) / 4) = -1;
                end   
            else
                if bit_quad(2) == 1
                    Q((i + 3) / 4) = 1;
                else
                    Q((i + 3) / 4) = 3;
                end
        end    
        
        % Map the bit pairs to Q component
        if bit_quad(3) == 0
            if bit_quad(4) == 0
                I((i + 3) / 4) = -3;
            else
                I((i + 3) / 4) = -1;
            end   
        else
            if bit_quad(4) == 1
                I((i + 3) / 4) = 1;
            else
                I((i + 3) / 4) = 3;
            end
        end   
    end
    end
    symbols = I + 1i * Q;
    
    % No need to scale the symbols for an overall length of sqrt(10)
    
    modulated_signal = symbols;
   
end
