function ber = compute_BER(x, z)
x=x';
  % Find the minimum length between x and z
    min_length = min(length(x), length(z));

    % Truncate both vectors to the minimum length
    x = x(1:min_length);
    z = z(1:min_length);
num_errors = sum(x ~= z);

    % Compute the Bit Error Rate (BER)
  ber = num_errors / length(x);


end