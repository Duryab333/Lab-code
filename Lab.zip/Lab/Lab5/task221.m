clear all;
close all;

%% Setup
% Define parameters.
M = 16;          % Size of signal constellation
k = log2(M);    % Number of bits per symbol
n = 3e4;        % Number of bits to process
nsamp = 4;      % Oversampling rate

%% Signal Source
% Create a binary data stream as a column vector.
x = randi([0 1], n, 1);   % Random binary data stream

% Bit-to-Symbol Mapping
y = bits_to_symbols(x, M);

%% Transmit Filter
% Define filter-related parameters.
filtorder = 40;               % Filter order
rolloff = 1;                  % Rolloff factor of filter
% tx filter and upsampling
ytx = DM_tx_filter(filtorder, rolloff, nsamp, y);

%% Channel
% Send signal over an AWGN channel.
snr = 20;
ynoisy = addNoise(ytx, snr);

%% Receive Filter
% rx filter and downsampling
yrx = DM_rx_filter(filtorder, rolloff, nsamp, ynoisy);

%% Scatter Plot (Symbol Space Diagrams)
% Before Filtering


scatterplot(y(1:5e3), 1, 0, 'g.');
title('Symbol Space Diagram - Gernated Symboles');

% After Filtering
scatterplot(ytx(1:5e3), 1, 0, 'r.');
title('Symbol Space Diagram - After Filtering');

scatterplot(ynoisy(1:5e3), 1, 0, 'g.');
title('Symbol Space Diagram - After Adding Noise');

% After Filtering

scatterplot(yrx(1:5e3), 1, 0, 'r.');
title('Symbol Space Diagram - At Reciever Filtering');
