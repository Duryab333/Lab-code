function ytx = DM_tx_filter(filtorder, rolloff, nsamp, y);
% Written by IB, dec22
%
% ytx = DM_tx_filter(filtorder, rolloff, nsamp, y) interpolates and filters
% with an rrc filter. 
%

delay = filtorder/(nsamp*2);    % Group delay (# of input samples)

% Create a raised cosine filter.    
rrcfilter = rcosdesign(rolloff,10,4,'sqrt');


% Plot impulse response.
%figure(2); impz(rrcfilter,1);
%figure(3); freqz(rrcfilter,4);

% upsample and apply raised cosine filter.
% Upsample
    y_upsampled = upsample(y, nsamp); % increase sample rate pf single by inserting zeros

    % Apply raised cosine filter
    ytx = conv(y_upsampled, rrcfilter, 'full'); %  convolution between raised cosin and upsampled signal

    % Remove trailing and leading zeros
    ytx = ytx(filtorder + 1:end - filtorder);


%ytx = rcosflt(y,1,nsamp,'filter',rrcfilter);
%scatterplot(y(1:5e3),1,0,'rx'); % optional

end

% $Id$
