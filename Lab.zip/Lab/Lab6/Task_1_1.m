% Communication system simulation with noise impairment

% System parameters
bitrate = 1e6; % Reduced bitrate for quicker simulation
duration = 1; % Duration in seconds
symbolRate = 28e9; % Symbol rate of 28 Giga-Baud
llw = 10e3; % Lorentzian linewidth of 10 kHz
SNR = 20; % Signal-to-Noise Ratio in dB

% Generate bit stream
bitstream = GenerateBitStream(bitrate, duration);

% Map bits to symbols (QPSK)
modulated_signal = bits2symbols(bitstream);

% Add phase noise to the signal
signal_with_phase_noise = addPhaseNoise(modulated_signal, symbolRate, llw);

% Add AWGN to the signal with phase noise
signal_with_all_noise = addNoise(signal_with_phase_noise, SNR);

% Perform hard decision decoding
hardDecodedSymbols = hardDec(signal_with_all_noise);

% Demap the symbols back to bit sequence
receivedBitstream = symbols2bits(hardDecodedSymbols);

% Calculate BER
bitErrors = sum(bitstream ~= receivedBitstream);
ber = bitErrors / length(bitstream);

% Output the BER result
fprintf('The Bit Error Rate (BER) is: %e\n', ber);
