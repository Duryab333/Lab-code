% Communication system simulation with llw = 1 MHz and carrier phase recovery

% System parameters
bitrate = 1e6; % Reduced bitrate for quicker simulation
duration = 1; % Duration in seconds
symbolRate = 28e9; % Symbol rate of 28 Giga-Baud
SNR = 20; % Signal-to-Noise Ratio in dB
llw = 1e6; % Lorentzian linewidth of 1 MHz

% Run the simulation
simulateCommunicationSystem(bitrate, duration, symbolRate, SNR, llw);

function simulateCommunicationSystem(bitrate, duration, symbolRate, SNR, llw)
    % Generate bit stream
    bitstream = GenerateBitStream(bitrate, duration);

    % Map bits to symbols (QPSK)
    modulated_signal = bits2symbols(bitstream);

    % Add phase noise to the signal
    signal_with_phase_noise = addPhaseNoise(modulated_signal, symbolRate, llw);

    % Add AWGN to the signal with phase noise
    signal_with_all_noise = addNoise(signal_with_phase_noise, SNR);

    % Apply carrier phase recovery
    recovered_signal = carrierPhaseRecovery(signal_with_all_noise);

    % Plot the signal constellation before phase recovery
    figure;
    plot(real(signal_with_all_noise), imag(signal_with_all_noise), '.');
    title(['Signal with AWGN and Phase Noise llw=' num2str(llw) ' Hz (Before Phase Recovery)']);
    xlabel('In-phase Component');
    ylabel('Quadrature Component');
    grid on;

    % Plot the signal constellation after phase recovery
    figure;
    plot(real(recovered_signal), imag(recovered_signal), '.');
    title(['Signal with AWGN and Phase Noise llw=' num2str(llw) ' Hz (After Phase Recovery)']);
    xlabel('In-phase Component');
    ylabel('Quadrature Component');
    grid on;

    % Perform hard decision decoding
    hardDecodedSymbols = hardDec(recovered_signal);

    % Demap the symbols back to bit sequence
    receivedBitstream = symbols2bits(hardDecodedSymbols);

    % Calculate BER
    bitErrors = sum(bitstream ~= receivedBitstream);
    ber = bitErrors / length(bitstream);

    % Output the BER result
    fprintf('BER with llw=%d Hz after phase recovery: %e\n', llw, ber);
end

