% Communication system simulation with llw = 1 MHz
% System parameters
bitrate = 1e6; % Reduced bitrate for quicker simulation
duration = 1; % Duration in seconds
symbolRate = 28e9; % Symbol rate of 28 Giga-Baud
SNR = 20; % Signal-to-Noise Ratio in dB
llw = 1e6; % Lorentzian linewidth of 100 kHz

% Run the simulation
simulateCommunicationSystem(bitrate, duration, symbolRate, SNR, llw);

function simulateCommunicationSystem(bitrate, duration, symbolRate, SNR, llw)
    % Generate bit stream
    bitstream = GenerateBitStream(bitrate, duration);

    % Map bits to symbols (QPSK)
    modulated_signal = bits2symbols(bitstream);

    % Add phase noise to the signal
    signal_with_phase_noise = addPhaseNoise(modulated_signal, symbolRate, llw);

    % Add AWGN to the signal with phase noise
    signal_with_all_noise = addNoise(signal_with_phase_noise, SNR);

    % Plot the signal constellation
    figure;
    plot(real(signal_with_all_noise), imag(signal_with_all_noise), '.');
    title(['Signal with AWGN and Phase Noise llw=' num2str(llw) ' Hz']);
    xlabel('In-phase Component');
    ylabel('Quadrature Component');
    grid on;

    % Perform hard decision decoding
    hardDecodedSymbols = hardDec(signal_with_all_noise);

    % Demap the symbols back to bit sequence
    receivedBitstream = symbols2bits(hardDecodedSymbols);

    % Calculate BER
    bitErrors = sum(bitstream ~= receivedBitstream);
    ber = bitErrors / length(bitstream);

    % Output the BER result
    fprintf('BER with llw=%d Hz: %e\n', llw, ber);
end
