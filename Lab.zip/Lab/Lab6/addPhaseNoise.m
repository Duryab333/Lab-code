function xout = addPhaseNoise(xin, rSym, llw)

% Function to add phase distortions to the signal
% rSym: Symbolrate
% llw: lorentzian linewidth (or laser linewidth)
% rng() sets the random seed. 
rng(1995)
N=length(xin);
signa=(sqrt(2*pi*llw*(1/(rSym))))*randn(N,1);
a=signa(1);
signa(1)=0;
spn=cumsum(signa,1);
spn(1)=a;
xin=xin(:); spn=spn(:);
xout= xin.*exp(1j*spn);

end