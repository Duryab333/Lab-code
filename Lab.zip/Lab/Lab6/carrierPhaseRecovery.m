function xout = carrierPhaseRecovery (xin)

% M=4 for QPSK (Modulation Order)
M=4;

% kk = 11. This is the filter length of a moving average filter.
kk=11;

x01 = xin.*exp(-1i*(pi/4));
ExM = x01.^M;
COMP1=movmean(ExM,2*kk+1);
argu1=(1/4)*unwrap(angle(COMP1));

x02=x01.*exp(-1j*(argu1-pi/4));

xout=x02;

end
